Simple Stopwatch
Press ENTER to start

Stopwatch started. Press ENTER to stop.

Elapsed time: 4.87 seconds