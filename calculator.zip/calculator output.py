Please select operation -
1. Add
2. Subtract
3. Multiply
4. Divide

Select operations form 1, 2, 3, 4 :1
Enter first number: 27
Enter second number: 31
27 + 31 = 58


Please select operation -
1. Add
2. Subtract
3. Multiply
4. Divide

Select operations form 1, 2, 3, 4 :2
Enter first number: 27
Enter second number: 31
27 - 31 = -4


Please select operation -
1. Add
2. Subtract
3. Multiply
4. Divide

Select operations form 1, 2, 3, 4 :3
Enter first number: 27
Enter second number: 31
27 * 31 = 837


Please select operation -
1. Add
2. Subtract
3. Multiply
4. Divide

Select operations form 1, 2, 3, 4 :4
Enter first number: 27
Enter second number: 31
27 / 31 = 0.8709677419354839
